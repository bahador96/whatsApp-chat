class MyProfiles {
  final String nyProfile, name, chat;
  final int countMessages;
  final double hour;

  MyProfiles({
    required this.nyProfile,
    required this.name,
    required this.chat,
    required this.countMessages,
    required this.hour,
  });

  static List<MyProfiles> get profiles {
    return [
      MyProfiles(
        nyProfile: 'assets/images/profile1.jpg',
        name: "Amin",
        chat: "Hi, How are you",
        countMessages: 2,
        hour: 12.30,
      ),
      MyProfiles(
        nyProfile: 'assets/images/profile2.jpg',
        name: "Amin",
        chat: "Hi, How are you",
        countMessages: 2,
        hour: 12.30,
      ),
      MyProfiles(
        nyProfile: 'assets/images/profile3.jpg',
        name: "Amin",
        chat: "Hi, How are you",
        countMessages: 2,
        hour: 18.30,
      ),
      MyProfiles(
        nyProfile: 'assets/images/profile4.jpg',
        name: "Amin",
        chat: "Hi, How are you today",
        countMessages: 5,
        hour: 13.30,
      ),
    ];
  }
}
